package com.example.drivetomsu;

import static org.junit.Assert.*;

public class MainActivityTest {

}